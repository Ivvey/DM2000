//THIS ONLY WORKS IN INSTAGRAM
//THIS DOES NOT CURRENTLY WORK FOR FACEBOOK

// Required Modules
const Materials = require('Materials');
const Scene = require('Scene');
const NativeUI = require('NativeUI');
const Textures = require('Textures');

// Find your objects
const rectangle0 = Scene.root.find('rectangle0');
const rectangle1 = Scene.root.find('rectangle1');

// Set an index of 0
const index = 0;

// Create a configuration object
const configuration = {

  // The index of the selected item in the picker
  selectedIndex: index,

  // The image textures to use as the items in the picker
  // Make sure these textures are set to uncompressed or this *will not work*
  items: [
    {image_texture: Textures.get('blue')},
    {image_texture: Textures.get('red')},
    {image_texture: Textures.get('white')},
    {image_texture: Textures.get('yellow')},
    {image_texture: Textures.get('green')}
  ],

  // OPTIONAL:
  // In this example we are switching materials
  // so I have included an object of materials
  // that matches the order of the textures above
  mats: [
    {material: Materials.get("blue")},
    {material: Materials.get("red")},
    {material: Materials.get("white")},
    {material: Materials.get("yellow")},
    {material: Materials.get("green")}
  ]
};

// Create our picker
const picker = NativeUI.picker;

// Load the configuration
picker.configure(configuration);

// Set the visibility to true
picker.visible = true;

// When the user selects an item form the picker, pass the index
// so we can select the materials to switch out
picker.selectedIndex.monitor().subscribe(function(val) {

    // Set the material to the first rectangle
    rectangle0.material = configuration.mats[val.newValue].material;

    // Set the material to the second rectangle
    rectangle1.material = configuration.mats[val.newValue].material;
});